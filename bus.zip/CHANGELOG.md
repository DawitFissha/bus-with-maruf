# Change Log

## [0.0.2] 2021-11-16
### Improvements

- Added Docker Support
- Fixes:
  - `Environment key "jest/globals" is unknown`
    - Impacted file: `package.json`

## [0.0.1] 2021-07-15
### Initial Release

- Integrate with Node JS Backend
- UI: amin dashborad v0.1.0 (free version)
