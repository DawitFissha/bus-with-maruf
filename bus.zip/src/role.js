export const role={
    OWNER:"owner",
    SUPERADMIN:"superadmin",
    ADMIN:"admin",
    CASHER:"casher",
    AGENT:"agent",
    DRIVER:"driver"
}
